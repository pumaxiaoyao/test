﻿<? header("content-Type: text/html; charset=UTF-8");?>
<?php

	
	include_once("./merchant.php");
	
	
	

	$interface_version = "V3.1.0";
	
	$mer_transfer_no=date( 'YmdHis' );
	
	$merchant_no="1111110166";
	
	$tran_code="DMTI";
	
	$recv_bank_code="ICBC";
	
	$recv_accno="54444444466";
	
	$recv_name="张三";
	
	$recv_province="44";
	
	$recv_city="5840";
	
	$tran_amount="50";
	
	$tran_fee_type="1";
	
	$tran_type="0";
	
	$remark="123";
	
	$sign_type="RSA-S";
	
				

	
	$signStr= "";
	
	$signStr = $signStr."interface_version=".$interface_version."&";
	
	$signStr = $signStr."mer_transfer_no=".$mer_transfer_no."&";
	
	$signStr = $signStr."merchant_no=".$merchant_no."&";
			
	$signStr = $signStr."recv_accno=".$recv_accno."&";
	
	$signStr = $signStr."recv_bank_code=".$recv_bank_code."&";
	
	$signStr = $signStr."recv_city=".$recv_city."&";
	
	$signStr = $signStr."recv_name=".$recv_name."&";
	
	$signStr = $signStr."recv_province=".$recv_province."&";
	
	if($remark != ""){
		$signStr = $signStr."remark=".$remark."&";
	}
	
	$signStr = $signStr."tran_amount=".$tran_amount."&";
	
	$signStr = $signStr."tran_code=".$tran_code."&";
	
	$signStr = $signStr."tran_fee_type=".$tran_fee_type."&";
	
	$signStr = $signStr."tran_type=".$tran_type;
	

	$merchant_private_key= openssl_get_privatekey($merchant_private_key);
	
	openssl_sign($signStr,$encryptData,$merchant_private_key,OPENSSL_ALGO_MD5);
	
	$sign_info = base64_encode($encryptData);
		

	$data =array("merchant_no"=>$merchant_no,
				"tran_type"=>$tran_type,
				"tran_fee_type"=>$tran_fee_type,
				"tran_code"=>$tran_code,
				"sign_type"=>$sign_type,
				"sign_info"=>$sign_info,
				"tran_amount"=>$tran_amount,
				"remark"=>$remark,
				"recv_province"=>$recv_province,
				"recv_name"=>$recv_name,
				"recv_city"=>$recv_city,
				"recv_accno"=>$recv_accno,
				"mer_transfer_no"=>$mer_transfer_no,
				"recv_bank_code"=>$recv_bank_code,
				"interface_version"=>$interface_version
	);
	
	
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL,"https://transfer.zfbill.net/transfer");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$data=curl_exec($ch);
	
	if($data){
	
	
	$result = simplexml_load_string($data);
	
	var_dump($result);
	
	}
	curl_close($ch);
?>    
  
	
	
	


