﻿<?php

	include_once("./merchant.php");
	
	
	

	$mer_transfer_no ="20160616120833";
	
	$merchant_no ="1111110166";
	
	$tran_code ="DMTQ";
	
	$interface_version="V3.1.0";
	
	$sign_type ="RSA-S";
	
		
	
	
	$signStr= "";
	
	$signStr = $signStr."interface_version=".$interface_version."&";
	
	$signStr = $signStr."mer_transfer_no=".$mer_transfer_no."&";
	
	$signStr = $signStr."merchant_no=".$merchant_no."&";
	
	$signStr = $signStr."tran_code=".$tran_code;
	
		
	$merchant_private_key= openssl_get_privatekey($merchant_private_key);
	
	openssl_sign($signStr,$encrypted,$priKey,OPENSSL_ALGO_MD5);
	
	$sign_info=base64_encode($encrypted);
	
    	
	
	
	$data =array("merchant_no"=>$merchant_no,
				"mer_transfer_no"=>$mer_transfer_no,
				"tran_code"=>$tran_code,
				"sign_type"=>$sign_type,
				"sign_info"=>$sign_info,
				"interface_version"=>$interface_version
	);
	
	
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL,"https://transfer.zfbill.net/transfer");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$data=curl_exec($ch);
	
	if($data){
	
	
	$result = simplexml_load_string($data);
	
	var_dump($result);
	
	}
	curl_close($ch);
	
	
	
	
?>
