﻿<?php

/////////////////////// get the value of "sign" parameter(RSA-S encrypt)/////////////////////
/*1)merchant_private_key,get it from the tools for getting keys,please refer to the file call <how to get the keys>
  2)you also need to get the merchant_public_key and upload it on Dinpay mechant system,also refer to <how to get the keys>
  3)the merchant_private_key and merchant_public_key are for mechant ID 1111110166,please get yours
*/	
	$merchant_private_key= '-----BEGIN RSA PRIVATE KEY-----
MIICXAIBAAKBgQDCZlyNoYw0aOsiCwE1KiiaLKz6r6VL91Eda8FTu2LnQbIu9PBz
hR9nJ1T3mDBsDQKGkes62rNukh7LFqKOZJGmIwlyCEsVrUMhD2J/6/XFDamsu2zG
ABoEyyIYJTr77zTN9Q27lgE3nfT19rwGMyxNnPA7Axl94TaJXOoiIkIjLQIDAQAB
AoGAFcc96ygD+wMeBGxTME+OyObkYhk3XXFRhwhBWk4N4HZ9rcEHBwoM4JOJc0t7
cT9r3wON5MQHggWgqYPZpjYiEtabUNZ0opbq8w0CQKumqLbzfSpxM/AKO8oR5GZq
eEtOn4UWBLOkUiS22qKBW2IsibhKvhG/g4x6hmG3W4F1skkCQQDsydZiWU82kXo0
0U6PsRoFWnQGG0n2Q7KvBF4Y8yeCF7OvOqcj0eoumKE6t/A2XrfmYDHn4cUPpOAZ
wvw0FR/nAkEA0iwZ8po4bW9nZUu/RqxsExyFAGkucuxLICwBlgxSBzKfRN1EyOaB
fdS3tjpp9zoY7UoCHZpsLeWF97U6IBCRywJBANx5uvJsMgOfRWi0ky/cOVxOssWU
1zNEKbYonO0iSuEo7Jf2RvZlWGX2m/kul64oV5dcblt4rqI4ZKnYEjj0inUCQBlU
C0R7ZXV6yYEhocmImfWrqDOmeVyMMXmNFBvbHD+V0C/iYpm7fbuGWSVy4LZUoBBo
rNyYcZUOZhi2FG0s0gUCQAn9ZTxdV7/WGKnIbDT103sKIHtugSgfuF/hpLFlvsn0
1YMYBnaQx1LN/Y1hPLg0uVb6q5equLMgR+I+RpYwi30=
-----END RSA PRIVATE KEY-----';

	//copy the contents between -----BEGIN PUBLIC KEY----- and -----END PUBLIC KEY----,then upload paste the contents on Dinpay mechant system
	$merchant_public_key = '-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDCZlyNoYw0aOsiCwE1KiiaLKz6r
6VL91Eda8FTu2LnQbIu9PBzhR9nJ1T3mDBsDQKGkes62rNukh7LFqKOZJGmIwlyCE
sVrUMhD2J/6/XFDamsu2zGABoEyyIYJTr77zTN9Q27lgE3nfT19rwGMyxNnPA7Axl
94TaJXOoiIkIjLQIDAQAB
-----END PUBLIC KEY-----';
	
	

	



?>