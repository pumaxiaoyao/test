﻿using System;
using System.Web;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Linq;
using System.Drawing;
using System.Text.RegularExpressions;
using DinpayRSAAPI.COM.Dinpay.RsaUtils;

namespace CSharpTestPay
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
               
				////////////////////////To receive the parameter form HTML form//////////////////////

                string interface_version = Request.Form["interface_version"].ToString().Trim();
                string merchant_no = Request.Form["merchant_no"].ToString().Trim();
                string sign_type = Request.Form["sign_type"].ToString().Trim();
                string mer_transfer_no = Request.Form["mer_transfer_no"].ToString().Trim();
                string tran_code = Request.Form["tran_code"].ToString().Trim();
                string recv_bank_code = Request.Form["recv_bank_code"].ToString().Trim();
                string recv_accno = Request.Form["recv_accno"].ToString().Trim();
                string recv_name = Request.Form["recv_name"].ToString().Trim();
                string recv_province = Request.Form["recv_province"].ToString().Trim();
                string recv_city = Request.Form["recv_city"].ToString().Trim();
                string tran_amount = Request.Form["tran_amount"].ToString().Trim();
                string tran_fee_type = Request.Form["tran_fee_type"].ToString().Trim();
                string tran_type = Request.Form["tran_type"].ToString().Trim();
                string remark = Request.Form["remark"].ToString().Trim();

              
                string signStr = "";

                if (interface_version != "")
                {
                    signStr = signStr + "interface_version=" + interface_version + "&";
                }
                if (mer_transfer_no != "")
                {
                    signStr = signStr + "mer_transfer_no=" + mer_transfer_no + "&";
                }
                if (merchant_no != "")
                {
                    signStr = signStr + "merchant_no=" + merchant_no + "&";
                }
                if (recv_accno != "")
                {
                    signStr = signStr + "recv_accno=" + recv_accno + "&";
                }
                if (recv_bank_code != "")
                {
                    signStr = signStr + "recv_bank_code=" + recv_bank_code + "&";
                }
                if (recv_city != "")
                {
                    signStr = signStr + "recv_city=" + recv_city + "&";
                }
                if (recv_name != "")
                {
                    signStr = signStr + "recv_name=" + recv_name + "&";
                }
                if (recv_province != "")
                {
                    signStr = signStr + "recv_province=" + recv_province + "&";
                }
                if (remark != "")
                {
                    signStr = signStr + "remark=" + remark + "&";
                }
                if (tran_amount != "")
                {
                    signStr = signStr + "tran_amount=" + tran_amount + "&";
                }
                if (tran_code != "")
                {
                    signStr = signStr + "tran_code=" + tran_code + "&";
                }
                if (tran_fee_type != "")
                {
                    signStr = signStr + "tran_fee_type=" + tran_fee_type + "&";
                }
                if (tran_type != "")
                {
                    signStr = signStr + "tran_type=" + tran_type ;
                }
                
                if (sign_type == "RSA-S")//for sign_type = "RSA-S"
                {
                   /*1)merchant_private_key,get it from the tools for getting keys,please refer to the file call <how to get the keys>
				     2)you also need to get the merchant_public_key and upload it on Dinpay mechant system,also refer to <how to get the keys>
				    3)this merchant_private_key is for mechant ID 1111110166,please get yours
					*/	
                    string merchant_private_key = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAMJmXI2hjDRo6yILATUqKJosrPqvpUv3UR1rwVO7YudBsi708HOFH2cnVPeYMGwNAoaR6zras26SHssWoo5kkaYjCXIISxWtQyEPYn/r9cUNqay7bMYAGgTLIhglOvvvNM31DbuWATed9PX2vAYzLE2c8DsDGX3hNolc6iIiQiMtAgMBAAECgYAVxz3rKAP7Ax4EbFMwT47I5uRiGTddcVGHCEFaTg3gdn2twQcHCgzgk4lzS3txP2vfA43kxAeCBaCpg9mmNiIS1ptQ1nSilurzDQJAq6aotvN9KnEz8Ao7yhHkZmp4S06fhRYEs6RSJLbaooFbYiyJuEq+Eb+DjHqGYbdbgXWySQJBAOzJ1mJZTzaRejTRTo+xGgVadAYbSfZDsq8EXhjzJ4IXs686pyPR6i6YoTq38DZet+ZgMefhxQ+k4BnC/DQVH+cCQQDSLBnymjhtb2dlS79GrGwTHIUAaS5y7EsgLAGWDFIHMp9E3UTI5oF91Le2Omn3OhjtSgIdmmwt5YX3tTogEJHLAkEA3Hm68mwyA59FaLSTL9w5XE6yxZTXM0Qptiic7SJK4Sjsl/ZG9mVYZfab+S6XrihXl1xuW3iuojhkqdgSOPSKdQJAGVQLRHtldXrJgSGhyYiZ9auoM6Z5XIwxeY0UG9scP5XQL+Jimbt9u4ZZJXLgtlSgEGis3JhxlQ5mGLYUbSzSBQJACf1lPF1Xv9YYqchsNPXTewoge26BKB+4X+GksWW+yfTVgxgGdpDHUs39jWE8uDS5Vvqrl6q4syBH4j5GljCLfQ==";
                  
                     merchant_private_key = testOrder.HttpHelp.RSAPrivateKeyJava2DotNet(merchant_private_key);
                 
                     string signData = testOrder.HttpHelp.RSASign(signStr, merchant_private_key);
                  
                     signData = HttpUtility.UrlEncode(signData);
                 
                     string para = signStr + "&sign_type=" + sign_type + "&sign_info=" + signData;
                    
                     string _xml = testOrder.HttpHelp.HttpPost("https://transfer.dinpay.com/transfer", para);
                     _xml = HttpUtility.HtmlEncode(_xml);
                     Response.Write(_xml);
                     Response.End();
                     
                }
                else  //for sign_type = "RSA-S"
                {
                    RSAWithHardware rsa = new RSAWithHardware();
                    string merPubKeyDir = "D:/1111110166.pfx";   //get the pfx cetification on Dinpay mechant system,"Payment Management"->"Download Cetification",1111110166.pfx is for merchant ID 1111110166
                    string password = "87654321";               //cetification's pwd,pwd is your merchant ID  
                    RSAWithHardware rsaWithH = new RSAWithHardware();
                    rsaWithH.Init(merPubKeyDir, password, "D:/dinpayRSAKeyVersion");
                    string signData = rsaWithH.Sign(signStr);   
                    signData = HttpUtility.UrlEncode(signData);  

                  
                    string para = signStr + "&sign_type=" + sign_type + "&sign_info=" + signData;
                  
                    string _xml = testOrder.HttpHelp.HttpPost("https://transfer.dinpay.com/transfer", para);
                    _xml = HttpUtility.HtmlEncode(_xml);
                    Response.Write(_xml);
                    Response.End();
                }
            }
			finally{
            }
        }
    }
}