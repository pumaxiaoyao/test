﻿using System;
using System.Web;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using DinpayRSAAPI.COM.Dinpay.RsaUtils;



namespace testOrderQuery
{
    public partial class getXmlData : System.Web.UI.Page
    {      
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
				/////////////////////////////////接收表单提交参数//////////////////////////////////////
				////////////////////////To receive the parameter form HTML form//////////////////////

                string merchant_no = Request.Form["merchant_no"].ToString().Trim();

                string tran_code = Request.Form["tran_code"].ToString().Trim();

                string sign_type = Request.Form["sign_type"].ToString().Trim();

                string interface_version = Request.Form["interface_version"].ToString().Trim();

                string mer_transfer_no = Request.Form["mer_transfer_no"].ToString().Trim();
   

				/////////////////////////////   数据签名  /////////////////////////////////
				////////////////////////////  Data signature  ////////////////////////////
                string signStr = "interface_version=" + interface_version + "&mer_transfer_no=" + mer_transfer_no + "&merchant_no=" + merchant_no + "&tran_code=" + tran_code;

                if (sign_type == "RSA-S") //RSA-S签名方法
                {
                    //商家私钥
                    string merchant_private_key = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAMJmXI2hjDRo6yILATUqKJosrPqvpUv3UR1rwVO7YudBsi708HOFH2cnVPeYMGwNAoaR6zras26SHssWoo5kkaYjCXIISxWtQyEPYn/r9cUNqay7bMYAGgTLIhglOvvvNM31DbuWATed9PX2vAYzLE2c8DsDGX3hNolc6iIiQiMtAgMBAAECgYAVxz3rKAP7Ax4EbFMwT47I5uRiGTddcVGHCEFaTg3gdn2twQcHCgzgk4lzS3txP2vfA43kxAeCBaCpg9mmNiIS1ptQ1nSilurzDQJAq6aotvN9KnEz8Ao7yhHkZmp4S06fhRYEs6RSJLbaooFbYiyJuEq+Eb+DjHqGYbdbgXWySQJBAOzJ1mJZTzaRejTRTo+xGgVadAYbSfZDsq8EXhjzJ4IXs686pyPR6i6YoTq38DZet+ZgMefhxQ+k4BnC/DQVH+cCQQDSLBnymjhtb2dlS79GrGwTHIUAaS5y7EsgLAGWDFIHMp9E3UTI5oF91Le2Omn3OhjtSgIdmmwt5YX3tTogEJHLAkEA3Hm68mwyA59FaLSTL9w5XE6yxZTXM0Qptiic7SJK4Sjsl/ZG9mVYZfab+S6XrihXl1xuW3iuojhkqdgSOPSKdQJAGVQLRHtldXrJgSGhyYiZ9auoM6Z5XIwxeY0UG9scP5XQL+Jimbt9u4ZZJXLgtlSgEGis3JhxlQ5mGLYUbSzSBQJACf1lPF1Xv9YYqchsNPXTewoge26BKB+4X+GksWW+yfTVgxgGdpDHUs39jWE8uDS5Vvqrl6q4syBH4j5GljCLfQ==";
                    //私钥转换成C#专用私钥
                    merchant_private_key = testOrderQuery.HttpHelp.RSAPrivateKeyJava2DotNet(merchant_private_key);
                    //签名
                    string signData = testOrderQuery.HttpHelp.RSASign(signStr, merchant_private_key);
                    //将signData进行UrlEncode编码
                    signData = HttpUtility.UrlEncode(signData);
                    //组装字符串
                    string para = signStr + "&sign_type=" + sign_type + "&sign_info=" + signData;
                    //用HttpPost方式提交
                    string _xml = HttpHelp.HttpPost("https://transfer.dinpay.com/transfer", para);
                    //将返回的xml中的参数提取出来
                    var el = XElement.Load(new StringReader(_xml));
                    //提取参数
                    var interface_version1 = el.XPathSelectElement("/interface_version");
                    var mer_transfer_no1 = el.XPathSelectElement("/mer_transfer_no");
                    var merchant_no1 = el.XPathSelectElement("/merchant_no");
                    var tran_code1 = el.XPathSelectElement("/tran_code");
                    var transfer_no1 = el.XPathSelectElement("/transfer_no");
                    var tran_apply_amount1 = el.XPathSelectElement("/tran_apply_amount");
                    var tran_amount1 = el.XPathSelectElement("/tran_amount");
                    var tran_fee_type1 = el.XPathSelectElement("/tran_fee_type");
                    var tran_date1 = el.XPathSelectElement("/tran_date");
                    var result_code1 = el.XPathSelectElement("/result_code");
                    var recv_code1 = el.XPathSelectElement("/recv_code");
                    var recv_info1 = el.XPathSelectElement("/recv_info");
                    var dinpaysign1 = el.XPathSelectElement("/sign_info");
                    //去掉首尾的标签并转换成string
                    string recv_info2 = Regex.Match(recv_info1.ToString(), "(?<=>).*?(?=<)").Value;
                    if (recv_info2 != "转账成功")
                    {
                        Response.Write("查询失败:" + _xml + "<br/>");
                        Response.End();
                    }
                    string interface_version2 = Regex.Match(interface_version1.ToString(), "(?<=>).*?(?=<)").Value; 
                    string mer_transfer_no2 = Regex.Match(mer_transfer_no1.ToString(), "(?<=>).*?(?=<)").Value;
                    string merchant_no2 = Regex.Match(merchant_no1.ToString(), "(?<=>).*?(?=<)").Value;
                    string tran_code2 = Regex.Match(tran_code1.ToString(), "(?<=>).*?(?=<)").Value;
                    string transfer_no2 = Regex.Match(transfer_no1.ToString(), "(?<=>).*?(?=<)").Value;
                    string tran_apply_amount2 = Regex.Match(tran_apply_amount1.ToString(), "(?<=>).*?(?=<)").Value;
                    string tran_amount2 = Regex.Match(tran_amount1.ToString(), "(?<=>).*?(?=<)").Value;
                    string tran_fee_type2 = Regex.Match(tran_fee_type1.ToString(), "(?<=>).*?(?=<)").Value;
                    string tran_date2 = Regex.Match(tran_date1.ToString(), "(?<=>).*?(?=<)").Value;
                    string recv_code2 = Regex.Match(recv_code1.ToString(), "(?<=>).*?(?=<)").Value;
                    string result_code2 = Regex.Match(result_code1.ToString(), "(?<=>).*?(?=<)").Value;
                    string dinpaysign = Regex.Match(dinpaysign1.ToString(), "(?<=>).*?(?=<)").Value;
                    //组装字符串
                    string signsrc = "interface_version=" + interface_version2 + "&mer_transfer_no=" + mer_transfer_no2 + "&merchant_no=" + merchant_no2 + "&recv_code=" + recv_code2 + "&recv_info=" + recv_info2 + "&result_code=" + result_code2 + "&tran_amount=" + tran_amount2 + "&tran_apply_amount=" + tran_apply_amount2 + "&tran_code=" + tran_code2 + "&tran_date=" + tran_date2 + "&tran_fee_type=" + tran_fee_type2 + "&transfer_no=" + transfer_no2;
                    //使用智付公钥对数据验签
                    string dinpay_public_key = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCWOq5aHSTvdxGPDKZWSl6wrPpn" +
                        "MHW+8lOgVU71jB2vFGuA6dwa/RpJKnz9zmoGryZlgUmfHANnN0uztkgwb+5mpgme" +
                        "gBbNLuGqqHBpQHo2EsiAhgvgO3VRmWC8DARpzNxknsJTBhkUvZdy4GyrjnUrvsAR" +
                        "g4VrFzKDWL0Yu3gunQIDAQAB";
                    //将智付公钥转换成C#专用格式
                    dinpay_public_key = testOrderQuery.HttpHelp.RSAPublicKeyJava2DotNet(dinpay_public_key);
                    //验签
                    bool validateResult = testOrderQuery.HttpHelp.ValidateRsaSign(signsrc, dinpay_public_key, dinpaysign);
                    if (validateResult == false)
                    {
                        Response.Write("验签失败");
                        Response.End();
                    }
                    Response.Write("验签成功");
                }
                else  //RSA签名方法
                {
                    RSAWithHardware rsa = new RSAWithHardware();
                    string merPubKeyDir = "D:/1111110166.pfx";   //证书路径
                    string password = "87654321";                //证书密码
                    RSAWithHardware rsaWithH = new RSAWithHardware();
                    rsaWithH.Init(merPubKeyDir, password, "D:/dinpayRSAKeyVersion");//初始化。设置dinpayRSAKeyVersion的路径与证书路径一致即可
                    string signData = rsaWithH.Sign(signStr);    //签名
                    signData = HttpUtility.UrlEncode(signData);  //将signData进行UrlEncode编码
                    //组装字符串
                    string para = signStr + "&sign_type=" + sign_type + "&sign_info=" + signData;
                    //用HttpPost方式提交
                    string _xml = HttpHelp.HttpPost("https://transfer.dinpay.com/transfer", para);
                    //将返回的xml中的参数提取出来
                    var el = XElement.Load(new StringReader(_xml));
                    //提取参数
                    var interface_version1 = el.XPathSelectElement("/interface_version");
                    var mer_transfer_no1 = el.XPathSelectElement("/mer_transfer_no");
                    var merchant_no1 = el.XPathSelectElement("/merchant_no");
                    var tran_code1 = el.XPathSelectElement("/tran_code");
                    var transfer_no1 = el.XPathSelectElement("/transfer_no");
                    var tran_apply_amount1 = el.XPathSelectElement("/tran_apply_amount");
                    var tran_amount1 = el.XPathSelectElement("/tran_amount");
                    var tran_fee_type1 = el.XPathSelectElement("/tran_fee_type");
                    var tran_date1 = el.XPathSelectElement("/tran_date");
                    var result_code1 = el.XPathSelectElement("/result_code");
                    var recv_code1 = el.XPathSelectElement("/recv_code");
                    var recv_info1 = el.XPathSelectElement("/recv_info");
                    var dinpaysign1 = el.XPathSelectElement("/sign_info");
                    //去掉首尾的标签并转换成string
                    string recv_info2 = Regex.Match(recv_info1.ToString(), "(?<=>).*?(?=<)").Value;
                    if (recv_info2 != "转账成功")
                    {
                        Response.Write("查询失败:" + _xml + "<br/>");
                        Response.End();
                    }
                    string interface_version2 = Regex.Match(interface_version1.ToString(), "(?<=>).*?(?=<)").Value;
                    string mer_transfer_no2 = Regex.Match(mer_transfer_no1.ToString(), "(?<=>).*?(?=<)").Value;
                    string merchant_no2 = Regex.Match(merchant_no1.ToString(), "(?<=>).*?(?=<)").Value;
                    string tran_code2 = Regex.Match(tran_code1.ToString(), "(?<=>).*?(?=<)").Value;
                    string transfer_no2 = Regex.Match(transfer_no1.ToString(), "(?<=>).*?(?=<)").Value;
                    string tran_apply_amount2 = Regex.Match(tran_apply_amount1.ToString(), "(?<=>).*?(?=<)").Value;
                    string tran_amount2 = Regex.Match(tran_amount1.ToString(), "(?<=>).*?(?=<)").Value;
                    string tran_fee_type2 = Regex.Match(tran_fee_type1.ToString(), "(?<=>).*?(?=<)").Value;
                    string tran_date2 = Regex.Match(tran_date1.ToString(), "(?<=>).*?(?=<)").Value;
                    string recv_code2 = Regex.Match(recv_code1.ToString(), "(?<=>).*?(?=<)").Value;
                    string result_code2 = Regex.Match(result_code1.ToString(), "(?<=>).*?(?=<)").Value;
                    string dinpaysign = Regex.Match(dinpaysign1.ToString(), "(?<=>).*?(?=<)").Value;
                    //组装字符串
                    string signsrc = "interface_version=" + interface_version2 + "&mer_transfer_no=" + mer_transfer_no2 + "&merchant_no=" + merchant_no2 + "&recv_code=" + recv_code2 + "&recv_info=" + recv_info2 + "&result_code=" + result_code2 + "&tran_amount=" + tran_amount2 + "&tran_apply_amount=" + tran_apply_amount2 + "&tran_code=" + tran_code2 + "&tran_date=" + tran_date2 + "&tran_fee_type=" + tran_fee_type2 + "&transfer_no=" + transfer_no2;
                    //验签
                    bool result = rsaWithH.VerifySign("1111110166", signsrc, dinpaysign);
                    if (result == false)
                    {
                        Response.Write("验签失败");
                        Response.End();
                    }
                    Response.Write("验签成功");
                }


            }
            finally
            {
            }
        }  
    }
}