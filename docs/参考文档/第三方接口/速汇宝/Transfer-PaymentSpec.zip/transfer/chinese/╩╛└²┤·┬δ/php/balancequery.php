﻿<?php
/* *
 *功能：速汇宝余额查询接口
 *版本：3.1.0
 *日期：2016-07-10
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,
 *并非一定要使用该代码。该代码仅供学习和研究速汇宝接口使用，仅为提供一个参考。
 **/
 
 
	
///////////////////////////  初始化接口参数  //////////////////////////////
/**
接口参数请参考速汇宝微信支付文档，除了sign参数，其他参数都要在这里初始化
*/
	include_once("./merchant.php");
	
	$interface_version="V3.1.0";
	
	$tran_code = "DMBQ";
	
	$merchant_no = "1111110166";//商户号，1111110166是测试商户号，调试时要更换商家自己的商户号
	
	$sign_type = "RSA-S";
	
/////////////////////////////   参数组装  /////////////////////////////////
/**
除了sign_type quickpaySign参数，其他非空参数都要参与组装，组装顺序是按照a~z的顺序，下划线"_"优先于字母
*/	
	
	$signStr= "";
	
	$signStr = $signStr."interface_version=".$interface_version."&";
	
	$signStr = $signStr."merchant_no=".$merchant_no."&";
	
	$signStr = $signStr."tran_code=".$tran_code;
	

/////////////////////////////   RSA-S签名  /////////////////////////////////


	
/////////////////////////////////初始化商户私钥//////////////////////////////////////

	
	$merchant_private_key= openssl_get_privatekey($merchant_private_key);
	
	
	openssl_sign($signStr,$encrypted,$merchant_private_key,OPENSSL_ALGO_MD5);
	
	$sign_info=base64_encode($encrypted);
	
/////////////////////////  提交参数到速汇宝支企互联网关  ////////////////////////
/**
curl方法提交支付参数到速汇宝支企互联网关https://transfer.zfbill.net/transfer，并且获取返回值
*/	
    	
	
	
	$data =array("merchant_no"=>$merchant_no,
				"tran_code"=>$tran_code,
				"sign_type"=>$sign_type,
				"sign_info"=>$sign_info,
				"interface_version"=>$interface_version
	);
	
	
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL,"https://transfer.zfbill.net/transfer");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$data=curl_exec($ch);
	
	if($data){
	
	
	$result = simplexml_load_string($data);
	
	var_dump($result);
	
	}
	curl_close($ch);

?>