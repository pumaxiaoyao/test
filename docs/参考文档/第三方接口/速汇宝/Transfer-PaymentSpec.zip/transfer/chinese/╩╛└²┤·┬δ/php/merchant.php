﻿<?php
/**
1）merchant_private_key，商户私钥;merchant_public_key,商户公钥；商户需要按照《密钥对获取工具说明》操作并获取商户私钥，商户公钥。
2）demo提供的merchant_private_key、merchant_public_key是测试商户号1111110166的商户私钥和商户公钥，请商家自行获取并且替换；
3）使用商户私钥加密时需要调用到openssl_sign函数,需要在php_ini文件里打开php_openssl插件
4）php的商户私钥在格式上要求换行，如下所示；
*/
	$merchant_private_key= '-----BEGIN RSA PRIVATE KEY-----
MIICXAIBAAKBgQDCZlyNoYw0aOsiCwE1KiiaLKz6r6VL91Eda8FTu2LnQbIu9PBz
hR9nJ1T3mDBsDQKGkes62rNukh7LFqKOZJGmIwlyCEsVrUMhD2J/6/XFDamsu2zG
ABoEyyIYJTr77zTN9Q27lgE3nfT19rwGMyxNnPA7Axl94TaJXOoiIkIjLQIDAQAB
AoGAFcc96ygD+wMeBGxTME+OyObkYhk3XXFRhwhBWk4N4HZ9rcEHBwoM4JOJc0t7
cT9r3wON5MQHggWgqYPZpjYiEtabUNZ0opbq8w0CQKumqLbzfSpxM/AKO8oR5GZq
eEtOn4UWBLOkUiS22qKBW2IsibhKvhG/g4x6hmG3W4F1skkCQQDsydZiWU82kXo0
0U6PsRoFWnQGG0n2Q7KvBF4Y8yeCF7OvOqcj0eoumKE6t/A2XrfmYDHn4cUPpOAZ
wvw0FR/nAkEA0iwZ8po4bW9nZUu/RqxsExyFAGkucuxLICwBlgxSBzKfRN1EyOaB
fdS3tjpp9zoY7UoCHZpsLeWF97U6IBCRywJBANx5uvJsMgOfRWi0ky/cOVxOssWU
1zNEKbYonO0iSuEo7Jf2RvZlWGX2m/kul64oV5dcblt4rqI4ZKnYEjj0inUCQBlU
C0R7ZXV6yYEhocmImfWrqDOmeVyMMXmNFBvbHD+V0C/iYpm7fbuGWSVy4LZUoBBo
rNyYcZUOZhi2FG0s0gUCQAn9ZTxdV7/WGKnIbDT103sKIHtugSgfuF/hpLFlvsn0
1YMYBnaQx1LN/Y1hPLg0uVb6q5equLMgR+I+RpYwi30=
-----END RSA PRIVATE KEY-----';

	//merchant_public_key,商户公钥，按照说明文档上传此密钥到速汇宝商家后台，位置为"支企互联设置"->"公钥管理"->"设置商户公钥"，代码中不使用到此变量
	$merchant_public_key = '-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDCZlyNoYw0aOsiCwE1KiiaLKz6r
6VL91Eda8FTu2LnQbIu9PBzhR9nJ1T3mDBsDQKGkes62rNukh7LFqKOZJGmIwlyCE
sVrUMhD2J/6/XFDamsu2zGABoEyyIYJTr77zTN9Q27lgE3nfT19rwGMyxNnPA7Axl
94TaJXOoiIkIjLQIDAQAB
-----END PUBLIC KEY-----';
	



	



?>