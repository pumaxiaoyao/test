﻿using System;
using System.Web;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Linq;
using System.Drawing;
using System.Text.RegularExpressions;
using DinpayRSAAPI.COM.Dinpay.RsaUtils;

namespace CSharpTestPay
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                /////////////////////////////////接收表单提交参数////////////////////////////////////
				////////////////////////To receive the parameter form HTML form//////////////////////

                string interface_version = Request.Form["interface_version"].ToString().Trim();
                string merchant_no = Request.Form["merchant_no"].ToString().Trim();
                string sign_type = Request.Form["sign_type"].ToString().Trim();
                string mer_transfer_no = Request.Form["mer_transfer_no"].ToString().Trim();
                string tran_code = Request.Form["tran_code"].ToString().Trim();
                string recv_bank_code = Request.Form["recv_bank_code"].ToString().Trim();
                string recv_accno = Request.Form["recv_accno"].ToString().Trim();
                string recv_name = Request.Form["recv_name"].ToString().Trim();
                string recv_province = Request.Form["recv_province"].ToString().Trim();
                string recv_city = Request.Form["recv_city"].ToString().Trim();
                string tran_amount = Request.Form["tran_amount"].ToString().Trim();
                string tran_fee_type = Request.Form["tran_fee_type"].ToString().Trim();
                string tran_type = Request.Form["tran_type"].ToString().Trim();
                string remark = Request.Form["remark"].ToString().Trim();

                ////////////////组装签名参数//////////////////
                string signStr = "";

                if (interface_version != "")
                {
                    signStr = signStr + "interface_version=" + interface_version + "&";
                }
                if (mer_transfer_no != "")
                {
                    signStr = signStr + "mer_transfer_no=" + mer_transfer_no + "&";
                }
                if (merchant_no != "")
                {
                    signStr = signStr + "merchant_no=" + merchant_no + "&";
                }
                if (recv_accno != "")
                {
                    signStr = signStr + "recv_accno=" + recv_accno + "&";
                }
                if (recv_bank_code != "")
                {
                    signStr = signStr + "recv_bank_code=" + recv_bank_code + "&";
                }
                if (recv_city != "")
                {
                    signStr = signStr + "recv_city=" + recv_city + "&";
                }
                if (recv_name != "")
                {
                    signStr = signStr + "recv_name=" + recv_name + "&";
                }
                if (recv_province != "")
                {
                    signStr = signStr + "recv_province=" + recv_province + "&";
                }
                if (remark != "")
                {
                    signStr = signStr + "remark=" + remark + "&";
                }
                if (tran_amount != "")
                {
                    signStr = signStr + "tran_amount=" + tran_amount + "&";
                }
                if (tran_code != "")
                {
                    signStr = signStr + "tran_code=" + tran_code + "&";
                }
                if (tran_fee_type != "")
                {
                    signStr = signStr + "tran_fee_type=" + tran_fee_type + "&";
                }
                if (tran_type != "")
                {
                    signStr = signStr + "tran_type=" + tran_type ;
                }
                
                if (sign_type == "RSA-S")//RSA-S签名方法
                {
                    //商家私钥
                    string merchant_private_key = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAMJmXI2hjDRo6yILATUqKJosrPqvpUv3UR1rwVO7YudBsi708HOFH2cnVPeYMGwNAoaR6zras26SHssWoo5kkaYjCXIISxWtQyEPYn/r9cUNqay7bMYAGgTLIhglOvvvNM31DbuWATed9PX2vAYzLE2c8DsDGX3hNolc6iIiQiMtAgMBAAECgYAVxz3rKAP7Ax4EbFMwT47I5uRiGTddcVGHCEFaTg3gdn2twQcHCgzgk4lzS3txP2vfA43kxAeCBaCpg9mmNiIS1ptQ1nSilurzDQJAq6aotvN9KnEz8Ao7yhHkZmp4S06fhRYEs6RSJLbaooFbYiyJuEq+Eb+DjHqGYbdbgXWySQJBAOzJ1mJZTzaRejTRTo+xGgVadAYbSfZDsq8EXhjzJ4IXs686pyPR6i6YoTq38DZet+ZgMefhxQ+k4BnC/DQVH+cCQQDSLBnymjhtb2dlS79GrGwTHIUAaS5y7EsgLAGWDFIHMp9E3UTI5oF91Le2Omn3OhjtSgIdmmwt5YX3tTogEJHLAkEA3Hm68mwyA59FaLSTL9w5XE6yxZTXM0Qptiic7SJK4Sjsl/ZG9mVYZfab+S6XrihXl1xuW3iuojhkqdgSOPSKdQJAGVQLRHtldXrJgSGhyYiZ9auoM6Z5XIwxeY0UG9scP5XQL+Jimbt9u4ZZJXLgtlSgEGis3JhxlQ5mGLYUbSzSBQJACf1lPF1Xv9YYqchsNPXTewoge26BKB+4X+GksWW+yfTVgxgGdpDHUs39jWE8uDS5Vvqrl6q4syBH4j5GljCLfQ==";
                    //私钥转换成C#专用私钥
                     merchant_private_key = testOrder.HttpHelp.RSAPrivateKeyJava2DotNet(merchant_private_key);
                    //签名
                     string signData = testOrder.HttpHelp.RSASign(signStr, merchant_private_key);
                    //将signData进行UrlEncode编码
                     signData = HttpUtility.UrlEncode(signData);
                     //组装字符串
                     string para = signStr + "&sign_type=" + sign_type + "&sign_info=" + signData;
                     //将字符串发送到Dinpay网关
                     string _xml = testOrder.HttpHelp.HttpPost("https://transfer.dinpay.com/transfer", para);
                     _xml = HttpUtility.HtmlEncode(_xml);
                     Response.Write(_xml);
                     Response.End();
                     
                }
                else  //RSA签名方法
                {
                    RSAWithHardware rsa = new RSAWithHardware();
                    string merPubKeyDir = "D:/1111110166.pfx";   //证书路径
                    string password = "87654321";                //证书密码
                    RSAWithHardware rsaWithH = new RSAWithHardware();
                    rsaWithH.Init(merPubKeyDir, password, "D:/dinpayRSAKeyVersion");//初始化(version路径需跟证书一致，证书会自动生成version)
                    string signData = rsaWithH.Sign(signStr);    //签名
                    signData = HttpUtility.UrlEncode(signData);  //将signData进行UrlEncode编码

                    //组装字符串
                    string para = signStr + "&sign_type=" + sign_type + "&sign_info=" + signData;
                    //将字符串发送到Dinpay网关
                    string _xml = testOrder.HttpHelp.HttpPost("https://transfer.dinpay.com/transfer", para);
                    _xml = HttpUtility.HtmlEncode(_xml);
                    Response.Write(_xml);
                    Response.End();
                }
            }
			finally{
            }
        }
    }
}