$(function(){
	
	/**
	 * ����ʡ����Ϣ
	 * @memberOf {TypeName} 
	 * @return {TypeName} 
	 */
	$('#select2').change(function(){
		var proID = this.value;
		$('#select3').html("");
		$.ajax({
			url: "js/City.xml",
			dataType: 'xml',
			type: 'GET',
			timeout: 2000,
			error: function(xml)
			{
				alert("����City.xml�ļ�������");
			},
			success: function(xml)
			{
				$(xml).find("Province").each(function(i)
				{
					var province = $(this).attr("id");
					if(proID==province){
						var select3 = $('#select3');
						$(this).children().each(function(index, city) {
                            var newOption = $("<option></option>");
							newOption.val($(city).attr("id"));
							newOption.text($(city).text());
							select3.append(newOption);
                        });
						return;
					}
				});
			}
    	});
	});
	$('#select2').change();
});